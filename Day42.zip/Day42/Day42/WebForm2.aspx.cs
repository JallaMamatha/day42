﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Day42
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}