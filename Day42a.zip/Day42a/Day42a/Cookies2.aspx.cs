﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Day42a
{
    public partial class Cookies2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                string a = Request.Cookies["mycookie"]["Value1"];
                string b = Request.Cookies["mycookie"]["Value2"];

                Response.Write(a + "<br>"+ b);
            }
            catch(NullReferenceException ob)
            {
                Response.Write("Cookie not available after 20 sec :" + ob.Message);
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = Request.Cookies["mycookie"];

            cookie.Expires = DateTime.Now.AddSeconds(-20);
            Response.Cookies.Add(cookie);
        }
    }
}