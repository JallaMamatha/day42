﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Day42a
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        int i = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                ViewState["count"] = i;
            }

            Response.Write(IsPostBack + " i = " + i + " count = " + ViewState["count"]);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            i = (int)ViewState["count"];


            Response.Write("    INSIDE BUTTON CLICK" + " i = " + i + " count = " + ViewState["count"]);
            i++;
            Label1.Text = i.ToString();
            ViewState["count"] = i;
        }
    }
}