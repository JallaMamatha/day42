﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Day42a
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataClasses1DataContext context = new DataClasses1DataContext();

            var data = from prod in context.Catalogs
                       where prod.Id == 444
                       select new
                       {
                           prod.Id,
                           prod.Pname,
                           prod.Price
                       };

            DetailsView1.DataSource = data;
            DetailsView1.DataBind();

            var data1 = from prod in context.Catalogs
                        select prod;


            DetailsView2.DataSource = data1;
            DetailsView2.DataBind();

        }
    }
}